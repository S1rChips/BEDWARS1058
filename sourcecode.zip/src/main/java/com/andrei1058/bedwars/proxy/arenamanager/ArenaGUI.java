package com.andrei1058.bedwars.proxy.arenamanager;

import com.andrei1058.bedwars.proxy.BedWarsProxy;
import com.andrei1058.bedwars.proxy.api.ArenaStatus;
import com.andrei1058.bedwars.proxy.api.CachedArena;
import com.andrei1058.bedwars.proxy.configuration.ConfigPath;
import com.andrei1058.bedwars.proxy.configuration.SoundsConfig;
import com.andrei1058.bedwars.proxy.language.Language;
import com.andrei1058.bedwars.proxy.api.Messages;
import com.andrei1058.bedwars.proxy.language.LanguageManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class ArenaGUI implements Listener {

    private static final int GUI_SIZE = BedWarsProxy.config.getYml().getInt(ConfigPath.GENERAL_CONFIGURATION_ARENA_SELECTOR_SETTINGS_SIZE);
    private static final int RANDOM_BUTTON_SLOT = 48;
    private static HashMap<Player, Object[]> refresh = new HashMap<>();
    private static YamlConfiguration yml = BedWarsProxy.config.getYml();

    public static void refreshInv(Player p, Object[] data) {
        List<CachedArena> arenas;
        if (((String)data[1]).equalsIgnoreCase("default")) {
            arenas = new ArrayList<>(ArenaManager.getArenas());
        } else {
            arenas = new ArrayList<>();
            for (CachedArena a : ArenaManager.getArenas()){
                if (a.getArenaGroup().equalsIgnoreCase(data[1].toString())) arenas.add(a);
            }
        }

        if (!yml.getBoolean(ConfigPath.GENERAL_CONFIGURATION_ARENA_SELECTOR_SETTINGS_SHOW_PLAYING)) {
            arenas.removeIf(a -> a.getStatus() == ArenaStatus.PLAYING);
        }

        arenas = arenas.stream().sorted(ArenaManager.getComparator()).collect(Collectors.toList());

        int arenaKey = 0;
        for (String useSlot : BedWarsProxy.config.getString(ConfigPath.GENERAL_CONFIGURATION_ARENA_SELECTOR_SETTINGS_USE_SLOTS).split(",")) {
            int slot;
            try {
                slot = Integer.parseInt(useSlot);
            } catch (Exception e) {
                continue;
            }
            ItemStack i;
            ((Inventory)data[0]).setItem(slot, new ItemStack(Material.AIR));
            if (arenaKey >= arenas.size()) {
                continue;
            }

            CachedArena ca = arenas.get(arenaKey);

            String status;
            switch (ca.getStatus()) {
                case WAITING:
                    status = "waiting";
                    break;
                case STARTING:
                    status = "starting";
                    break;
                case PLAYING:
                    status = "playing";
                    break;
                default:
                    continue;
            }

            i = BedWarsProxy.getItemAdapter().createItem(yml.getString(ConfigPath.GENERAL_CONFIGURATION_ARENA_SELECTOR_STATUS_MATERIAL.replace("%path%", status)),
                    1, (byte) yml.getInt(ConfigPath.GENERAL_CONFIGURATION_ARENA_SELECTOR_STATUS_DATA.replace("%path%", status)));
            if (i == null) i = new ItemStack(Material.AIR);

            if (yml.getBoolean(ConfigPath.GENERAL_CONFIGURATION_ARENA_SELECTOR_STATUS_ENCHANTED.replace("%path%", status))) {
                if (i.getItemMeta() != null){
                    ItemMeta im = i.getItemMeta();
                    im.addEnchant(Enchantment.LURE, 1, true);
                    im.addItemFlags(ItemFlag.HIDE_ENCHANTS);
                    i.setItemMeta(im);
                }
            }

            ItemMeta im = i.getItemMeta();
            com.andrei1058.bedwars.proxy.api.Language lang = LanguageManager.get().getPlayerLanguage(p);
            if (im != null){
                im.setDisplayName(Language.getMsg(p, Messages.ARENA_GUI_ARENA_CONTENT_NAME).replace("{name}", ca.getDisplayName(lang)));
                List<String> lore = new ArrayList<>();
                for (String s : LanguageManager.get().getList(p, Messages.ARENA_GUI_ARENA_CONTENT_LORE)) {
                    if (!(s.contains("{group}") && ca.getArenaGroup().equalsIgnoreCase("default"))) {
                        lore.add(s.replace("{on}", String.valueOf(ca.getCurrentPlayers())).replace("{max}",
                                        String.valueOf(ca.getMaxPlayers())).replace("{status}", ca.getDisplayStatus(lang))
                                .replace("{group}", ca.getDisplayGroup(lang)));
                    }
                }
                im.setLore(lore);
                i.setItemMeta(im);
            }
            i = BedWarsProxy.getItemAdapter().addTag(i, "server", ca.getServer());
            i = BedWarsProxy.getItemAdapter().addTag(i, "world_identifier", ca.getRemoteIdentifier());
            i = BedWarsProxy.getItemAdapter().addTag(i, "cancelClick", "true");

            ((Inventory)data[0]).setItem(slot, i);
            arenaKey++;
        }

        if (yml.getBoolean(ConfigPath.GENERAL_CONFIGURATION_RANDOMARENAS)) {
            ItemStack randomButton = new ItemStack(Material.EYE_OF_ENDER);
            ItemMeta randomMeta = randomButton.getItemMeta();
            if (randomMeta != null) {
                randomMeta.setDisplayName(ChatColor.GOLD + "Random Map");
                List<String> lore = new ArrayList<>();
                lore.add(ChatColor.AQUA + "Click to join a random map!");
                lore.add(ChatColor.RED + "Mode: " + data[1].toString());
                randomMeta.setLore(lore);
                randomMeta.addEnchant(Enchantment.LUCK, 1, true);
                randomMeta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
                randomButton.setItemMeta(randomMeta);
            }
            randomButton = BedWarsProxy.getItemAdapter().addTag(randomButton, "random_arena", "true");
            randomButton = BedWarsProxy.getItemAdapter().addTag(randomButton, "arena_group", data[1].toString());
            ((Inventory)data[0]).setItem(RANDOM_BUTTON_SLOT, randomButton);
        }
    }

    public static void openGui(Player p, String group) {
        Inventory inv = Bukkit.createInventory(new SelectorHolder(), GUI_SIZE, Language.getMsg(p, Messages.ARENA_GUI_INV_NAME));

        ItemStack filler = BedWarsProxy.getItemAdapter().createItem(yml.getString(ConfigPath.GENERAL_CONFIGURATION_ARENA_SELECTOR_STATUS_MATERIAL.replace("%path%", "skipped-slot")),
                1, (byte) yml.getInt(ConfigPath.GENERAL_CONFIGURATION_ARENA_SELECTOR_STATUS_DATA.replace("%path%", "skipped-slot")));
        if (filler == null) filler = new ItemStack(Material.AIR);
        filler = BedWarsProxy.getItemAdapter().addTag(filler, "cancelClick", "true");

        if (filler.getItemMeta() != null) {
            ItemMeta im = filler.getItemMeta();
            im.setDisplayName(ChatColor.translateAlternateColorCodes('&', BedWarsProxy.config.getString(ConfigPath.GENERAL_CONFIG_PLACEHOLDERS_REPLACEMENTS_SERVER_IP)));
            im.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            filler.setItemMeta(im);
        }

        for (int x = 0; x < inv.getSize(); x++) {
            inv.setItem(x, filler);
        }

        p.openInventory(inv);
        refresh.put(p, new Object[]{inv, group});
        refreshInv(p, new Object[]{inv, group});
        SoundsConfig.playSound("arena-selector-open", p);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player)) return;
        if (e.getCurrentItem() == null) return;

        Player p = (Player) e.getWhoClicked();
        ItemStack clicked = e.getCurrentItem();

        if (e.getInventory().getHolder() instanceof SelectorHolder) {
            e.setCancelled(true);

            if (BedWarsProxy.getItemAdapter().getTag(clicked, "random_arena") != null) {
                String group = BedWarsProxy.getItemAdapter().getTag(clicked, "arena_group");
                p.closeInventory();
                joinRandomArena(p, group);
            }
        }
    }

    private static void joinRandomArena(Player player, String group) {
        Bukkit.dispatchCommand(player, "bw join " + group);
    }

    public static HashMap<Player, Object[]> getRefresh() {
        return refresh;
    }

    public static class SelectorHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }
}
