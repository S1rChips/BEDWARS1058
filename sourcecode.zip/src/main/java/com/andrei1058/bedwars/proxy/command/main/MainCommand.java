package com.andrei1058.bedwars.proxy.command.main;

import com.andrei1058.bedwars.proxy.command.ParentCommand;
import com.andrei1058.bedwars.proxy.BedWarsProxy;
import com.andrei1058.bedwars.proxy.language.Language;
import com.andrei1058.bedwars.proxy.api.Messages;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;

public class MainCommand extends ParentCommand {

    private static MainCommand instance;

    /**
     * Create a new Parent Command
     *
     * @param name
     */
    public MainCommand(String name) {
        super(name);
        instance = this;
        setAliases(Arrays.asList("bedwars"));
        addSubCommand(new SelectorCMD("gui", ""));
        addSubCommand(new LangCMD("lang", ""));
        addSubCommand(new LangCMD("language", ""));
        addSubCommand(new JoinCMD("join", ""));
        addSubCommand(new ReJoinCMD("rejoin", "bw.rejoin"));
        addSubCommand(new TpCommand("tp", "bw.tp"));
    }

    @Override
    public void sendDefaultMessage(CommandSender s) {
        if (s instanceof ConsoleCommandSender) return;
        Player p = (Player) s;

        if (p.hasPermission("bw.admin")){


            s.sendMessage(" ");
            s.sendMessage("§6§l▶" + " §4&lBedWars v1.0 by PotatoDevelopment");
            s.sendMessage("&c&lCommands:");
            s.sendMessage(" &f/bw tp <player> &7to teleport ingame player");
            s.sendMessage(" &f/bw rejoin &7to rejoin");
            s.sendMessage(" &f/bw join <arena> &7to join an arena");
            s.sendMessage(" &f/bw gui &7to open arena selector gui");
            s.sendMessage(" &f/bw lang &7to show languages");
            s.sendMessage("&c&lSocials:");
            s.sendMessage(" &cDISCORD: dsc.gg/potatodev");
            s.sendMessage(" &cWEBSITE: potatoshop.ir");
            s.sendMessage(" &cSTORE: potatoshop.ir/pdev");
        }else{
            s.sendMessage("§6§l▶" + " §4&lBedWars v1.0 by PotatoDevelopment");
            s.sendMessage("&cDISCORD: dsc.gg/potatodev");
            s.sendMessage("&cWEBSITE: potatoshop.ir");
            s.sendMessage("&cSTORE: potatoshop.ir/pdev");
        }
    }

    public static MainCommand getInstance() {
        return instance;
    }
}
